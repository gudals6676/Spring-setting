package co.min.domain;

import lombok.Data;

@Data
public class QuickVO {
	String q_name; //기사이름
	String age;
	String auto;  //차종
	String a_num; //번호판
	String q_num; //기사번호
}
