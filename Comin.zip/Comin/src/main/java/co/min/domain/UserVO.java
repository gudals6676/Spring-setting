package co.min.domain;

import lombok.Data;

@Data
public class UserVO {
	String name;
	String Ic_num; //주민번호
	String num;    //전화번호
	
}
